"""
IVEX Hairstyle Consulting - Appwrite Cloud Function
Uses GitHub Models (GPT-4o) for face analysis and Pollinations.ai for Img2Img hairstyle generation
"""

import os
import json
import base64
import time
import requests
import urllib.parse
from appwrite.client import Client
from appwrite.services.storage import Storage
from appwrite.services.databases import Databases
from appwrite.id import ID
from azure.ai.inference import ChatCompletionsClient
from azure.ai.inference.models import SystemMessage, UserMessage, TextContentItem, ImageContentItem, ImageUrl
from azure.core.credentials import AzureKeyCredential


def main(context):
    """
    Main entry point for the Appwrite Function.
    Triggered by storage.buckets.*.files.*.create events.
    """
    
    # Initialize environment variables
    APPWRITE_ENDPOINT = os.environ.get('APPWRITE_FUNCTION_API_ENDPOINT', 'https://fra.cloud.appwrite.io/v1')
    APPWRITE_PROJECT_ID = os.environ.get('APPWRITE_FUNCTION_PROJECT_ID')
    APPWRITE_API_KEY = os.environ.get('APPWRITE_API_KEY')
    GITHUB_TOKEN = os.environ.get('GITHUB_TOKEN')
    
    # Appwrite resource IDs
    BUCKET_ID = os.environ.get('BUCKET_ID', 'photos')
    DATABASE_ID = os.environ.get('DATABASE_ID', 'ivex_db')
    COLLECTION_ID = os.environ.get('COLLECTION_ID', 'results')
    
    context.log("IVEX Stylist Agent - Function triggered")
    
    # Parse the event payload
    try:
        event_data = context.req.body
        if isinstance(event_data, str):
            event_data = json.loads(event_data)
        
        context.log(f"Event data received: {json.dumps(event_data)[:500]}")
    except Exception as e:
        context.error(f"Failed to parse event data: {str(e)}")
        return context.res.json({"success": False, "error": "Invalid event data"})
    
    # Extract file information from the event
    file_id = event_data.get('$id') or event_data.get('fileId')
    bucket_id = event_data.get('bucketId', BUCKET_ID)
    
    if not file_id:
        context.error("No file ID found in event")
        return context.res.json({"success": False, "error": "No file ID in event"})
    
    context.log(f"Processing file: {file_id} from bucket: {bucket_id}")
    
    # Initialize Appwrite Client
    client = Client()
    client.set_endpoint(APPWRITE_ENDPOINT)
    client.set_project(APPWRITE_PROJECT_ID)
    client.set_key(APPWRITE_API_KEY)
    
    storage = Storage(client)
    databases = Databases(client)
    
    try:
        # Step 1: Get image URL (Public View URL for Pollinations & Analysis)
        context.log("Step 1: preparing image...")
        
        # We need the full URL for Pollinations to download the image
        # Assuming the bucket has 'Any' read permissions as configured previously
        image_url = f"{APPWRITE_ENDPOINT}/storage/buckets/{bucket_id}/files/{file_id}/view?project={APPWRITE_PROJECT_ID}"
        context.log(f"Image URL: {image_url}")
        
        # Download for GitHub Analysis (requires base64)
        response = requests.get(image_url, timeout=30)
        if response.status_code != 200:
            raise Exception(f"Failed to download image: {response.status_code}")
        
        file_content = response.content
        image_base64 = base64.b64encode(file_content).decode('utf-8')
        
        # Step 2: Create initial database entry
        context.log("Step 2: Creating database entry...")
        
        initial_doc = databases.create_document(
            database_id=DATABASE_ID,
            collection_id=COLLECTION_ID,
            document_id=ID.unique(),
            data={
                'original_file_id': file_id,
                'status': 'processing',
                'face_shape': '',
                'advice_text': '',
                'generated_image_url': '',
                'created_at': int(time.time() * 1000)
            }
        )
        
        doc_id = initial_doc['$id']
        context.log(f"Created document: {doc_id}")
        
        # Step 3: Analyze face with GitHub Models (GPT-4o)
        context.log("Step 3: Analyzing face shape with GitHub Models (GPT-4o)...")
        
        face_analysis = analyze_face_with_github_models(image_base64, GITHUB_TOKEN, context)
        context.log(f"Face analysis: {face_analysis.get('face_shape')}")
        
        # Step 4: Generate hairstyle with Pollinations Img2Img
        context.log("Step 4: Generating hairstyle with Pollinations Img2Img...")
        
        generated_image_url = generate_hairstyle_with_pollinations(
            prompt=face_analysis.get('stable_diffusion_prompt', ''),
            original_image_url=image_url,
            context=context
        )
        
        context.log(f"Generated image ready")
        
        # Step 5: Update database with results
        context.log("Step 5: Saving results...")
        
        databases.update_document(
            database_id=DATABASE_ID,
            collection_id=COLLECTION_ID,
            document_id=doc_id,
            data={
                'status': 'completed',
                'face_shape': face_analysis.get('face_shape', 'Unknown'),
                'advice_text': face_analysis.get('advice', 'Unable to generate advice'),
                'generated_image_url': generated_image_url
            }
        )
        
        context.log("IVEX Stylist Agent - Completed successfully!")
        
        return context.res.json({
            "success": True,
            "document_id": doc_id,
            "face_shape": face_analysis.get('face_shape')
        })
        
    except Exception as e:
        context.error(f"Error: {str(e)}")
        
        try:
            if 'doc_id' in locals():
                databases.update_document(
                    database_id=DATABASE_ID,
                    collection_id=COLLECTION_ID,
                    document_id=doc_id,
                    data={
                        'status': 'error',
                        'advice_text': f'Processing failed: {str(e)}'
                    }
                )
        except:
            pass
        
        return context.res.json({"success": False, "error": str(e)})


def analyze_face_with_github_models(image_base64: str, token: str, context) -> dict:
    """
    Analyze face shape using GitHub Models (GPT-4o) via Azure AI Inference SDK.
    """
    
    if not token:
        raise Exception("Missing GITHUB_TOKEN environment variable")

    endpoint = "https://models.github.ai/inference"
    model_name = "gpt-4o"

    context.log(f"Calling GitHub Models ({model_name})...")
    
    try:
        client = ChatCompletionsClient(
            endpoint=endpoint,
            credential=AzureKeyCredential(token),
        )
        
        prompt_text = """You are an expert face shape analyst and hair stylist.

CAREFULLY analyze the face in this image and determine the EXACT face shape.

Look at these features:
- Forehead width vs jawline width
- Cheekbone prominence
- Jaw angle and chin shape
- Face length vs width ratio

Face shapes to choose from:
1. OVAL - Forehead slightly wider than chin, gentle curve at jaw
2. ROUND - Equal width and length, full cheeks, soft angles
3. SQUARE - Strong angular jawline, forehead and jaw similar width
4. OBLONG/RECTANGLE - Face is longer than wide, straight cheek lines
5. HEART - Wide forehead, narrow chin, high cheekbones
6. DIAMOND - Narrow forehead and jaw, wide cheekbones
7. TRIANGLE - Narrow forehead, wide jaw

Respond with ONLY valid JSON (no markdown):
{
    "face_shape": "The EXACT face shape from the list above",
    "reasoning": "Brief explanation of why this shape was detected",
    "stable_diffusion_prompt": "URGENT: Create a prompt for Image-to-Image generation. Focus ONLY on hair. usage format: 'man with [hairstyle description], [hair texture]'. Do NOT describe the face, only the hair transformation.",
    "advice": "Specific barber advice for this face shape - what styles work, what to avoid"
}"""

        response = client.complete(
            messages=[
                SystemMessage("You are a helpful assistant capable of analyzing images."),
                UserMessage(
                    content=[
                        TextContentItem(text=prompt_text),
                        ImageContentItem(
                            image_url=ImageUrl(
                                url=f"data:image/jpeg;base64,{image_base64}",
                                detail="high"
                            )
                        ),
                    ],
                ),
            ],
            model=model_name,
            temperature=0.1,
            max_tokens=1000
        )
        
        text = response.choices[0].message.content.strip()
        
        if text.startswith('```'):
            text = '\n'.join(text.split('\n')[1:-1])
        if text.startswith('json'):
            text = text[4:].strip()
        
        result = json.loads(text)
        context.log(f"GPT-4o detected face shape: {result.get('face_shape')}")
        return result
        
    except Exception as e:
        error_str = str(e)
        context.error(f"GitHub Models error: {error_str}")
        raise


def generate_hairstyle_with_pollinations(prompt: str, original_image_url: str, context) -> str:
    """
    Generate hairstyle using Pollinations.ai Image-to-Image.
    This preserves the user's face and just changes the hair.
    """
    import random
    
    if not prompt:
        prompt = "man with modern stylish haircut"
    
    # Clean up prompt for Pollinations
    cleaned_prompt = prompt.replace('"', '').replace("'", "")
    
    # Add quality boosters
    full_prompt = f"photorealistic, {cleaned_prompt}, cinematic lighting, 8k, highly detailed hair texture"
    
    # URL Encode the prompt and image URL
    encoded_prompt = urllib.parse.quote(full_prompt)
    encoded_image = urllib.parse.quote(original_image_url)
    
    # Generate random seed to ensure new image each time
    seed = random.randint(1, 999999)
    
    # Pollinations URL with Image parameter
    pollinations_url = f"https://pollinations.ai/p/{encoded_prompt}?width=512&height=512&seed={seed}&model=flux&nologo=true&image={encoded_image}&strength=0.7"
    
    context.log(f"Generated Pollinations Img2Img URL (strength=0.7)")
    
    return pollinations_url
