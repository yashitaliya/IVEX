"""
IVEX Hairstyle Consulting — Appwrite Cloud Function
Face Shape Detection Pipeline using MediaPipe Face Mesh + Geometric Analysis

Pipeline:
  1. Download image from Appwrite Storage
  2. Preprocess (resize, normalize, RGB convert)
  3. Detect 468 facial landmarks via MediaPipe
  4. Extract geometric measurements (ratios)
  5. Classify face shape (weighted scoring)
  6. Generate hairstyle recommendations
  7. Generate visualization via Pollinations.ai
  8. Store results to Appwrite Database
"""

import os
import sys
import json
import base64
import time
import random
import urllib.parse
import requests

# Add the src directory to Python path for sibling imports
sys.path.insert(0, os.path.dirname(__file__))

from appwrite.client import Client
from appwrite.services.storage import Storage
from appwrite.services.databases import Databases
from appwrite.id import ID

# Local pipeline modules
from preprocess import preprocess_image
from landmark_detector import detect_landmarks, LandmarkDetectionError
from measurements import extract_measurements
from classifier import classify_face_shape
from recommender import (
    get_recommendations,
    generate_advice_text,
    generate_pollinations_prompt,
)


def main(context):
    """
    Appwrite Cloud Function entry point.
    Triggered by: buckets.photos.files.*.create
    """

    # ── Environment variables ──
    APPWRITE_ENDPOINT = os.environ.get(
        'APPWRITE_FUNCTION_API_ENDPOINT', 'https://fra.cloud.appwrite.io/v1'
    )
    APPWRITE_PROJECT_ID = os.environ.get('APPWRITE_FUNCTION_PROJECT_ID')
    APPWRITE_API_KEY = os.environ.get('APPWRITE_API_KEY')

    BUCKET_ID = os.environ.get('BUCKET_ID', 'photos')
    DATABASE_ID = os.environ.get('DATABASE_ID', 'ivex_db')
    COLLECTION_ID = os.environ.get('COLLECTION_ID', 'results')

    context.log("IVEX Face Analysis — Function triggered (MediaPipe Pipeline)")

    # ── Parse event payload ──
    try:
        event_data = context.req.body
        if isinstance(event_data, str):
            event_data = json.loads(event_data)
        context.log(f"Event data: {json.dumps(event_data)[:500]}")
    except Exception as e:
        context.error(f"Failed to parse event data: {e}")
        return context.res.json({"success": False, "error": "Invalid event data"})

    # ── Extract file info ──
    file_id = event_data.get('$id') or event_data.get('fileId')
    bucket_id = event_data.get('bucketId', BUCKET_ID)

    if not file_id:
        context.error("No file ID found in event")
        return context.res.json({"success": False, "error": "No file ID in event"})

    context.log(f"Processing file: {file_id} from bucket: {bucket_id}")

    # ── Initialize Appwrite ──
    client = Client()
    client.set_endpoint(APPWRITE_ENDPOINT)
    client.set_project(APPWRITE_PROJECT_ID)
    client.set_key(APPWRITE_API_KEY)

    storage = Storage(client)
    databases = Databases(client)

    doc_id = None

    try:
        # ═══════════════════════════════════════════
        # STEP 1: Download image
        # ═══════════════════════════════════════════
        context.log("Step 1/7: Downloading image...")

        image_url = (
            f"{APPWRITE_ENDPOINT}/storage/buckets/{bucket_id}"
            f"/files/{file_id}/view?project={APPWRITE_PROJECT_ID}"
        )
        response = requests.get(image_url, timeout=30)
        if response.status_code != 200:
            raise Exception(f"Failed to download image: HTTP {response.status_code}")

        image_bytes = response.content
        context.log(f"Image downloaded: {len(image_bytes)} bytes")

        # ═══════════════════════════════════════════
        # STEP 2: Create initial database entry
        # ═══════════════════════════════════════════
        context.log("Step 2/7: Creating database entry...")

        initial_doc = databases.create_document(
            database_id=DATABASE_ID,
            collection_id=COLLECTION_ID,
            document_id=ID.unique(),
            data={
                'original_file_id': file_id,
                'status': 'processing',
                'face_shape': '',
                'advice_text': '',
                'generated_image_url': '',
                'created_at': int(time.time() * 1000),
            }
        )
        doc_id = initial_doc['$id']
        context.log(f"Created document: {doc_id}")

        # ═══════════════════════════════════════════
        # STEP 3: Preprocess image
        # ═══════════════════════════════════════════
        context.log("Step 3/7: Preprocessing image...")

        processed_image, original_dims = preprocess_image(image_bytes)
        context.log(
            f"Preprocessed: {original_dims[0]}x{original_dims[1]} → "
            f"{processed_image.shape[1]}x{processed_image.shape[0]}"
        )

        # ═══════════════════════════════════════════
        # STEP 4: Detect face & extract contour
        # ═══════════════════════════════════════════
        context.log("Step 4/7: Detecting face contour (OpenCV)...")

        detection_result = detect_landmarks(processed_image)
        detection_confidence = detection_result['confidence']
        context.log(
            f"Face detected, confidence: {detection_confidence}"
        )

        # ═══════════════════════════════════════════
        # STEP 5: Extract geometric measurements
        # ═══════════════════════════════════════════
        context.log("Step 5/7: Extracting facial measurements...")

        face_measurements = extract_measurements(detection_result)
        context.log(
            f"Measurements: "
            f"W/H={face_measurements['width_height_ratio']}, "
            f"Jaw/Cheek={face_measurements['jaw_cheek_ratio']}, "
            f"Forehead/Cheek={face_measurements['forehead_cheek_ratio']}, "
            f"JawAngle={face_measurements['jawline_angle']}°"
        )

        # ═══════════════════════════════════════════
        # STEP 6: Classify face shape
        # ═══════════════════════════════════════════
        context.log("Step 6/7: Classifying face shape...")

        classification = classify_face_shape(face_measurements)
        face_shape = classification['face_shape']
        shape_confidence = classification['confidence']
        context.log(
            f"Detected: {face_shape.upper()} "
            f"(confidence: {shape_confidence})"
        )
        context.log(f"All scores: {classification['all_scores']}")

        # ═══════════════════════════════════════════
        # STEP 7: Generate recommendations + save
        # ═══════════════════════════════════════════
        context.log("Step 7/7: Generating recommendations & saving...")

        recommendations = get_recommendations(face_shape)
        advice_text = generate_advice_text(
            face_shape, face_measurements, shape_confidence
        )

        # Generate Pollinations image URL
        generated_image_url = _generate_pollinations_url(
            face_shape, image_url
        )

        # ── Build structured result payload ──
        # Serialized into advice_text as JSON for rich Flutter display
        structured_result = json.dumps({
            "confidence": shape_confidence,
            "measurements": {
                "widthHeightRatio": face_measurements['width_height_ratio'],
                "jawCheekRatio": face_measurements['jaw_cheek_ratio'],
                "foreheadCheekRatio": face_measurements['forehead_cheek_ratio'],
                "jawlineAngle": face_measurements['jawline_angle_normalized'],
            },
            "recommendations": {
                "recommended": recommendations['recommended'],
                "avoid": recommendations['avoid'],
                "tip": recommendations['tip'],
            },
            "advice": advice_text,
        })

        # ── Update database with final results ──
        databases.update_document(
            database_id=DATABASE_ID,
            collection_id=COLLECTION_ID,
            document_id=doc_id,
            data={
                'status': 'completed',
                'face_shape': face_shape,
                'advice_text': structured_result,
                'generated_image_url': generated_image_url,
            }
        )

        context.log(f"IVEX Face Analysis — Completed: {face_shape.upper()}")

        return context.res.json({
            "success": True,
            "document_id": doc_id,
            "faceDetected": True,
            "faceShape": face_shape,
            "confidence": shape_confidence,
            "measurements": {
                "widthHeightRatio": face_measurements['width_height_ratio'],
                "jawCheekRatio": face_measurements['jaw_cheek_ratio'],
                "foreheadCheekRatio": face_measurements['forehead_cheek_ratio'],
                "jawlineAngle": face_measurements['jawline_angle_normalized'],
            },
            "recommendations": recommendations['recommended'],
        })

    except LandmarkDetectionError as e:
        # Known face detection failure (no face, multi-face, low quality)
        context.error(f"Face detection error: {e}")
        _update_error(databases, DATABASE_ID, COLLECTION_ID, doc_id, str(e))
        return context.res.json({
            "success": False,
            "faceDetected": False,
            "error": str(e),
        })

    except ValueError as e:
        # Image validation or measurement errors
        context.error(f"Validation error: {e}")
        _update_error(databases, DATABASE_ID, COLLECTION_ID, doc_id, str(e))
        return context.res.json({
            "success": False,
            "faceDetected": False,
            "error": str(e),
        })

    except Exception as e:
        # Unexpected errors
        context.error(f"Unexpected error: {e}")
        _update_error(databases, DATABASE_ID, COLLECTION_ID, doc_id, str(e))
        return context.res.json({
            "success": False,
            "error": f"Processing failed: {e}",
        })


def _update_error(databases, db_id, col_id, doc_id, error_msg):
    """Update the database document with error status."""
    if doc_id is None:
        return
    try:
        databases.update_document(
            database_id=db_id,
            collection_id=col_id,
            document_id=doc_id,
            data={
                'status': 'error',
                'advice_text': error_msg,
            }
        )
    except Exception:
        pass  # Don't let error reporting cause another error


def _generate_pollinations_url(face_shape, original_image_url):
    """
    Generate a Pollinations.ai Img2Img URL for hairstyle visualization.

    Args:
        face_shape: str — detected face shape
        original_image_url: str — URL of the original uploaded image

    Returns:
        str: Pollinations image generation URL
    """
    from recommender import generate_pollinations_prompt

    prompt = generate_pollinations_prompt(face_shape)

    # Add quality boosters
    full_prompt = (
        f"photorealistic, {prompt}, "
        f"8k, highly detailed hair texture"
    )

    encoded_prompt = urllib.parse.quote(full_prompt)
    encoded_image = urllib.parse.quote(original_image_url)
    seed = random.randint(1, 999999)

    return (
        f"https://pollinations.ai/p/{encoded_prompt}"
        f"?width=512&height=512&seed={seed}"
        f"&model=flux&nologo=true"
        f"&image={encoded_image}&strength=0.7"
    )
